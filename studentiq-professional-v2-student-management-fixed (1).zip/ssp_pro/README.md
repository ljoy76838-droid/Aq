# StudentIQ — Professional Student Score Predictor

A full-stack academic analytics project for a BTech/CSE mini project or major project demo.

## Stack
- React + Vite
- Framer Motion
- Recharts
- Lucide React
- Flask REST API
- scikit-learn Random Forest regression
- SQLite for student records
- Pandas + NumPy

## Features
- Executive dashboard with KPIs, score distribution and trend charts
- Interactive score predictor with probability-style performance bands
- Student registry with search, filters, add/edit/delete, live forecast refresh and CSV export
- Intervention planner with a review queue and rule-based support focus
- Data Tools workspace with CSV template, bulk import, validation feedback and registry backup
- Batch CSV prediction endpoint
- Analytics page with attendance, study hours and previous score relationships
- Model insights and feature importance
- Report generator in the browser
- Dark/light theme, responsive mobile layout, keyboard-friendly controls
- REST API health check and structured error responses
- Seeded synthetic dataset so the project works offline
- Automated API tests

## Important academic note
The bundled model is trained on synthetic demonstration data. It is a working ML pipeline, but its predictions must not be treated as validated predictions of real students until you train it on an institution's real, ethically collected and representative data.

## Run
### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python train_model.py
python app.py
```
API: http://127.0.0.1:5000

### Frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite, normally http://localhost:5173.

## API
- `GET /api/health`
- `GET /api/dashboard`
- `GET /api/students`
- `POST /api/students`
- `PUT /api/students/<id>`
- `DELETE /api/students/<id>`
- `POST /api/students/import` (multipart CSV upload)
- `POST /api/predict`
- `POST /api/predict/batch`
- `GET /api/model/insights`

## Sample prediction JSON
```json
{
  "attendance": 86,
  "study_hours": 3.5,
  "previous_score": 72,
  "assignments": 88,
  "internal_marks": 76,
  "participation": 70,
  "sleep_hours": 7
}
```

## GitHub
This folder is ready to initialize as a Git repository. A suggested commit sequence is:
1. `feat: add professional React dashboard`
2. `feat: add Flask ML prediction API`
3. `feat: add student registry and analytics`
4. `test: add API smoke tests`
