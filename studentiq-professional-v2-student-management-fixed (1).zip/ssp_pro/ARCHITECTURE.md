# StudentIQ Architecture

```text
React/Vite UI
   |
   | JSON / CSV
   v
Flask REST API  ---- SQLite student registry
   |
   v
scikit-learn Random Forest
   |
   v
Prediction + band + feature importance
```

## Frontend modules
- Overview: operational KPIs, trajectory, score distribution, priority list
- Predictor: seven interactive model inputs and explainable drivers
- Students: registry, search, add/delete, forecast bands
- Analytics: cohort comparisons and health indicators
- Model Insights: model card, validation metrics, feature importance
- Reports: presentation-ready report preview and TXT export
- Settings: theme and stack information

## ML pipeline
1. Generate a seeded synthetic dataset.
2. Split 80/20 into train and validation sets.
3. Fit RandomForestRegressor.
4. Persist model with joblib.
5. Expose inference through `/api/predict`.
6. Expose feature importance through `/api/model/insights`.

## Production hardening ideas
- Replace synthetic data with consented, de-identified institutional data.
- Add authentication and role-based authorization.
- Add audit logging and rate limits.
- Store model versions and training datasets separately.
- Monitor drift and calibration.
- Never use predictions as the sole basis for high-impact decisions.
