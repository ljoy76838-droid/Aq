import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'backend'))
from app import app, init_db

def test_health():
    app.config['TESTING']=True
    with app.test_client() as c:
        assert c.get('/api/health').status_code==200

def test_predict():
    app.config['TESTING']=True
    with app.test_client() as c:
        payload={'attendance':90,'study_hours':4,'previous_score':80,'assignments':90,'internal_marks':82,'participation':75,'sleep_hours':7}
        r=c.post('/api/predict',json=payload); assert r.status_code==200; assert 0<=r.json['predicted_score']<=100


def test_student_create_update_delete():
    app.config['TESTING']=True
    payload={'name':'Test Student QA','student_code':'TEST-QA-CRUD-991','course':'B.Tech CSE','semester':'6th','attendance':82,'study_hours':3,'previous_score':70,'assignments':80,'internal_marks':75,'participation':70,'sleep_hours':7}
    with app.test_client() as c:
        r=c.post('/api/students',json=payload)
        assert r.status_code==201
        sid=r.json['id']
        payload['name']='Updated QA Student'
        assert c.put(f'/api/students/{sid}',json=payload).status_code==200
        assert c.delete(f'/api/students/{sid}').status_code==200

def test_student_duplicate_id_returns_clear_error():
    payload={'name':'Test Duplicate','student_code':'STU-DEMO-01','course':'B.Tech CSE','semester':'6th','attendance':82,'study_hours':3,'previous_score':70,'assignments':80,'internal_marks':75,'participation':70,'sleep_hours':7}
    with app.test_client() as c:
        r=c.post('/api/students',json=payload)
        assert r.status_code==409
        assert 'already exists' in r.json['error']
